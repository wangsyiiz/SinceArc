SinceArc 0.1.0（Windows x64 便携版）

怎么启动
  1. 解压到任意目录（不要在压缩包里直接双击）；
  2. 双击 SinceArc.exe。首次启动 SmartScreen 可能提示「未知发布者」，
     点「更多信息 → 仍要运行」（本版本未签名，见 docs/distribution.md §4）。

数据在哪
  %APPDATA%\com.sincearc.app\sincearc.db 与 logs\ 。
  数据不跟着这个文件夹走：换目录解压、删掉文件夹都不会删数据；
  要彻底清干净，删上面那个目录。

需要 WebView2 运行时（Win11 和较新的 Win10 自带）。
  启动时若提示缺 WebView2，去 https://developer.microsoft.com/microsoft-edge/webview2/
  装 Evergreen Runtime（x64）后再启动。

卸载
  便携版没有安装项：删掉这个文件夹即可（数据见上）。
